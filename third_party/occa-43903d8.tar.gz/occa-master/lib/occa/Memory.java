package occa;

public class Memory {
}