package occa;

public class StreamTag {
}