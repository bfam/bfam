classdef stream < handle
    properties
        cStream
    end
end