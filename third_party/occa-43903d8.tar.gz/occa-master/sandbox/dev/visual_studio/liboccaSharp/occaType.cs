﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace liboccaSharp {

    

    //public class occaType : OccaBase {

    //    public occaType(int value) {
    //        this.OccaHandle = occaInt(value);
    //    }
    //    public occaType(uint value){
    //        this.OccaHandle = occaUInt(value);
    //    }

    //    public occaType(sbyte value) {
    //        this.OccaHandle = occaChar(value);
    //    }
    //    public occaType(byte value) {
    //        this.OccaHandle = occaUChar(value);
    //    }
    //    public occaType(short value) {
    //        this.OccaHandle = occaShort(value);
    //    }
    //    public occaType(ushort value) {
    //        this.OccaHandle = occaUShort(value);
    //    }
    //    //public occaType(int value) {
    //    //    this.OccaHandle = occaLong(value);
    //    //}
    //    //public occaType(uint value) {
    //    //    this.OccaHandle = occaULong(value);
    //    //}
    //    public occaType(float value) {
    //        this.OccaHandle = occaFloat(value);
    //    }
    //    public occaType(double value) {
    //        this.OccaHandle = occaDouble(value);
    //    }
    //    public occaType(string value) {
    //        this.OccaHandle = occaString(value);
    //    }

    //    public override void Dispose() {
    //        base.OccaHandle = IntPtr.Zero;
    //        todo;
    //    }


    //    [DllImport("occa_c")]
    //    extern static IntPtr /*occaType*/ occaInt(int value);
    //    [DllImport("occa_c")]
    //    extern static IntPtr /*occaType*/ occaUInt(uint value);
    //    [DllImport("occa_c")]
    //    extern static IntPtr /*occaType*/ occaChar(sbyte value);
    //    [DllImport("occa_c")]
    //    extern static IntPtr /*occaType*/ occaUChar(byte value);
    //    [DllImport("occa_c")]
    //    extern static IntPtr /*occaType*/ occaShort(short value);
    //    [DllImport("occa_c")]
    //    extern static IntPtr /*occaType*/ occaUShort(ushort value);
    //    [DllImport("occa_c")]
    //    extern static IntPtr /*occaType*/ occaLong(int value);
    //    [DllImport("occa_c")]
    //    extern static IntPtr /*occaType*/ occaULong(uint value);
    //    [DllImport("occa_c")]
    //    extern static IntPtr /*occaType*/ occaFloat(float value);
    //    [DllImport("occa_c")]
    //    extern static IntPtr /*occaType*/ occaDouble(double value);
    //    [DllImport("occa_c")]
    //    extern static IntPtr /*occaType*/ occaString([MarshalAs(UnmanagedType.LPStr)] string str);
    //}
}
