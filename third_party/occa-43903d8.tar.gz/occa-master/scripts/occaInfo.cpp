#include "occa.hpp"

int main(int argc, char **argv){
  occa::printAvailableDevices();

  return 0;
}
